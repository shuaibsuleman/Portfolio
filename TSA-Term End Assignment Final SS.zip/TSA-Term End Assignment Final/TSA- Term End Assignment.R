#Time Series Analytics - Term end Assignment  O.P.Jindal Global University
#Shuaib Suleman                    Date: 20/11/22

#Importing Libraries
install.packages("tseries")
install.packages("forecast")
install.packages("ggplot2")
install.packages("fpp2")
install.packages("TSstudio")

library(tseries)
library(forecast)
library(readxl)
library(ggplot2)
library(fpp2)
library(TSstudio)

#######################Question 1#######################################
#Importing the data from Excel

library(readxl)
Oil_Prices <- read_excel("Documents/Lanseria Smart City/MBA/(JGU)OPJindal/Coursework/Semester 3/Time Series Analytics/Oil-Prices.xls")
View(Oil_Prices)
class(Oil_Prices)

#Creating a time series object from the data frame OIL PRICES
Oil_Data <- ts(Oil_Prices$MCOILWTICO, start = c(1986,1), frequency = 12)
head(Oil_Data)
str(Oil_Data) # The Data is now a time series

################################Question 2#############################

#Creating a time series plot form the data frame OIL PRICES
#View of the data
head(Oil_Data)

#setting the margin. rows and columns
par(mfrow=c(1,1), mar=c(2,2,1,1), cex.main=1.5)

#Plotting the time series data with O-type chart (One method)
ts.plot(Oil_Data, type="o", ylab="Monthly Price")

#Creating a time series plot (Second Method) with labeled axis
#What does the data look like? we plot the data in red
autoplot(Oil_Data, col="blue") +
  ggtitle("Price of Oil:") +
  xlab("Year") +
  ylab("Price") 


#Creating a seasonal Plot
ggseasonplot(Oil_Data, year.labels=TRUE, year.labels.left=TRUE) +
  ylab("$ Price") +
  ggtitle("Seasonal plot: Oil Price")


#create a seasonal sub-series plot
ggsubseriesplot(Oil_Data) +
  ylab("$ million") +
  ggtitle("Seasonal subseries plot: Oil Price")

#Create a lag plot
Oil_lag <- window(Oil_Data, start=1986)
gglagplot(Oil_lag)

#################################Question 3#############################
#Apply regression and forecast for 10 periods into he future
#Load the data
Oil2 <- window(Oil_Data, start=1986)

#Conduct the Dickey Fuller test to check p-value for stationarity
adf.test(Oil2)

#Check differencing, how many diffs are required?
ndiffs(Oil2) # 1 difference required to make series stationary
nsdiffs(Oil2)

#Remove trend by Differencing the data using diff function
Oil_Diff <- diff(Oil2)


#Conduct regression analysis
fit.oil <- tslm(Oil_Diff ~ trend + season)

#Output of regression Analysis
summary(fit.oil)

#Forecast of the series
fcastoil <- forecast(fit.oil, h=10)
autoplot(fcastoil) +
  ggtitle("Forecasts of oil price using regression analysis") +
  xlab("Year") + ylab("Change in Price")

#Alternatively to view and plot one can use the below command
print(summary(fit.oil))
print(summary(fcastoil))
plot(fcastoil)

#################################Question 4##############################
#Decomposition of a time series
Oil_Data %>%
  stl(t.window=13, s.window="periodic", robust=TRUE) %>%
  autoplot()

##################################Question 5############################
#Apply Exponential smoothing methods
#to the first differenced data
fit_ets <- ets(Oil_Diff)

#seasonal plot of the differenced data
ggseasonplot(Oil_Diff) + xlab("Year") + ylab("Change in Oil Price")

#Lets look at another seasonal subseries plot
ggsubseriesplot(Oil_Diff) + xlab("Year") + ylab("Change in Price")
#Our time series has trend and seasonality, to remove the trend we took the first difference

#Summary of the ETS Model
print(summary(fit_ets))

#Plot of the components of the model
autoplot(fit_ets)

#Check the residuals for non-correlation and independence
checkresiduals(fit_ets)

#we plot the residuals and the forecast errors to ensure constant mean and variance
cbind('Residuals' = residuals(fit_ets),
      'Forecast errors' = residuals(fit_ets,type='response')) %>%
  autoplot(facet=TRUE) + xlab("Year") + ylab("")

#plot the forecast of the oil price
fit_ets %>% forecast(h=10) %>%
  autoplot() +
  ylab("Forecasts of oil Price ")

#Forecast/Prediction values for the 10 months
fcast1 <- forecast(fit_ets, h=10)

#Print summary of the prediction for 10 months
print(summary(fcast1))

#Output of the ETN Model ETS(A,N,N)
print(summary(fit_ets))
plot.ts(Oil_Data)
lines(fitted(fit_ets), col = 'red')

###############################Question 6##############################
#Arima Modelling

Oil_Data %>% stl(s.window='periodic') %>% seasadj() -> Oil_Seesadj
autoplot(Oil_Seesadj)
ggtsdisplay(Oil_Seesadj) # we notice the trend in the ACF, the lags reduce gradually

#Determine stationarity - for ARIMA models data must be stationary,
#apply Augmented Dickey Fuller test to check for stationarity

Oil_Seesadj %>% diff() %>% ggtsdisplay(main="")
ndiffs(Oil_Seesadj) # Check for differencing I = 1
adf.test(Oil_Seesadj) # P-value  > 0.05

#differencing using diff method
Oil_Seesadj_diff=diff(Oil_Seesadj)

#Plots a time series along with its acf and either its pacf, 
#lagged scatterplot or spectrum.
ggtsdisplay(Oil_Seesadj_diff)

#Also conduct Augmented Dickey Fuller test to check p-value of diff. TS
adf.test(Oil_Seesadj_diff) #P-Value < 0.05 once differenced therefore 
#data is stationary

#Apply auto.arima to best fit the ARIMA model , AIC should be as 
#low as possible
fit_ARIMA <- auto.arima(Oil_Seesadj_diff,ic="aic", trace = TRUE, seasonal = TRUE)

#Print a summary of the  fit_ARIMA model
print(summary(fit_ARIMA))

#Check the ACF of the residuals to ensure data is stationary
acf(fit_ARIMA$residuals)

#Check the PACF
pacf(fit_ARIMA$residuals)

#Create our Model ARIMA (1,0,0)as being the best model
Model_Oil_Data = arima(Oil_Seesadj, order = c(1,0,0))
Model_Oil_Data
plot(Model_Oil_Data)
autoplot(Model_Oil_Data)

#Diagnostic Check Options - check the residuals for white noise after fitting 
#the model. We can use various methods
checkresiduals(Model_Oil_Data)

#other methods to obtain residuals
et=residuals(Model_Oil_Data)

#Is there any correlation between the residuals or not
acf(et) #There is no auto correlation

#check whether the residuals have a constant mean at zero or not
plot.ts(et)# mean should be around zero

#Check the histrogram to understand wheteher the residuals normally 
#distributed or not
gghistogram(et) # Bell shaped Histrogram

#Ljung-Box Test
Box.test(et, lag = 10, type = c("Ljung-Box"), fitdf = 3) # P-value is 
#significant

#Finally residuals are not correlated, normally distributed and 
#it has a zero mean

#H0= Resdiuals follow IID - independent, not correlated, 
#p-value is more than 5% of significance, we extract our null hypothesis
#it gives us the validity that the residuals are independent and therefore
#there is no correlation between residuals


#Forecast the series
forecast_Model_Oil_Data <- forecast(Model_Oil_Data, h=10)
forecast_Model_Oil_Data

#Plot the forecast
plot(forecast_Model_Oil_Data)

#to check the accuracy of the model
accuracy(forecast_Model_Oil_Data)
checkresiduals(Model_Oil_Data)

#Our Model is significant and accurate
autoplot(Oil_Data) + 
  autolayer(forecast_Model_Oil_Data$fitted, series = "Fitted")

print(summary(Model_Oil_Data))

####################Seasonal ARIMA MODEL###########################
#Overview of the data
Oil_Data %>% stl(s.window='periodic') 
autoplot(Oil_Data)
ggtsdisplay(Oil_Data)# we notice the trend reduces gradually from the ACF
#The PACF has one significant Lag at 1

#Check how many differences required to make the time series staionary
ndiffs(Oil_Data) # This is an I(1) series
nsdiffs(Oil_Data)# D = 0

# The data is clearly non-stationary, with no seasonality. Always take 
#the seasonal difference first if it exists

#We take the first differenced data
Oil_Diff <- diff(Oil_Data)
    ggtsdisplay(Oil_Diff)

ndiffs(Oil_Diff)# check that differencing has been done

#Taking the first difference through the diff process and display the 
#differenced time series. 
#The signficiant spike at lag 1 in the ACF and PACF suggests a
#seasonal MA(1) component 

#we use the AUTO.ARIMA function to select the best fit model
auto.arima(Oil_Diff)

#We begin with a seasonal ARIMA(2,0,1)(0,0,0)12 with non-zero mean

fit2 <- Arima(Oil_Data, order = c(2,0,1),
              seasonal = c(0,0,0),
                            lambda = NULL,
              include.constant = TRUE)

#Plot of fit1
autoplot(fit2)

#Check the residuals on `fit2` for non correlation and indpendance
checkresiduals(fit2, lag = 36)

#Check the summary of Fit1
summary(fit2)

#Another way to build a different model and then plot the ACF and PACF
Oil_Data %>%
  Arima(order = c(2,0,1), 
        seasonal = c(0,0,0),
        lambda = NULL,
        include.constant = TRUE)%>%
  residuals() %>%
  ggtsdisplay()

#Install LMtest package and library
install.packages("lmtest")
library(lmtest)

#check the coefficients for significance of the parameters
coeftest(fit2) # The ar1, ar2 and intercept coefficients are significant

#check the residuals
ggtsdisplay(fit2$residuals)

#Forecast for the next 10 months
Oil_Data %>%
  forecast(h=10) %>%
  autoplot()

#View and compare/check the fitted model
autoplot(Oil_Data) + 
  autolayer(fit2$fitted, series = "Fit")

#Print a summary of the model
print(summary(fit2))
print(summary(forecast(fit2, h=10)))


#Question 7
################

#We compute the forecast summary and accuracy measures for the models.

print(summary(fit.oil))
checkresiduals(fit.oil)
Box.test(fit.oil$residuals, lag = 20, type = "Ljung-Box")


print(summary(fit_ets))
checkresiduals(fit_ets)
Box.test(fit_ets$residuals, lag = 20, type = "Ljung-Box")

print(summary(Model_Oil_Data))
checkresiduals(Model_Oil_Data)
Box.test(Model_Oil_Data$residuals, lag = 20, type = "Ljung-Box")

print(summary(fit2))
checkresiduals(fit2)
Box.test(fit2$residuals, lag = 20, type = "Ljung-Box") #lag 20
Box.test(fit2$residuals, lag = 30, type = "Ljung-Box")# lag 30
Box.test(fit2$residuals, lag = 40, type = "Ljung-Box")# lag 40
Box.test(fit2$residuals, lag = 50, type = "Ljung-Box")#lag 50
Box.test(fit2$residuals, lag = 100, type = "Ljung-Box")#lag 100
###################################End#################################
