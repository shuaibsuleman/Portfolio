
options(warn = -1) #suppress warning messages
options(repr.plot.width = 13.7, repr.plot.height = 9.2)#sets the width and height of the plots that will be generated
set.seed(150)#sets a random seed for the script. It is used to ensure that the script will produce the same results when run multiple times with the same seed value. 
#This is useful for reproducibility and debugging purposes.

# install specific packages if they are not already installed 
install.packages("ggthemes")
install.packages("corrplot")
install.packages("adabag")
install.packages("randomForestSRC")
install.packages("Metrics")
install.packages("mgcv")
install.packages("mice")

#load the previously installed packages into the script's environment. 
#These libraries provide access to functions and data structures within the packages that can be used by the script.
library(ggplot2)
library(ggthemes)
library(dplyr)
library(RColorBrewer)
library(corrplot)
library(rpart)
library(rpart.plot)
library(adabag)
library(randomForestSRC)
library(scales)
library(Metrics)
library(mgcv)
library(lubridate)
library(mice)
library(caret)
library(car)

base <- read.csv("~/Documents/Lanseria Smart City/MBA/(JGU)OPJindal/Coursework/Semester 3/Predictive Analytics and Forecasting/data.csv") #load a CSV file
cat("Rows: ", nrow(base))#print the number of rows in the data frame
head(base,5)#print the first 5 rows
str(base)#structure of the data frame


# Check for missing values
missing_values <- function(base){
  miss_data <- base %>%
    is.na() %>%
    sum()
  return(miss_data)
}

# Print the missing values
print(missing_values(base)) # No missing values

options(scipen = 999)#set the scientific notation to a large number (999)

plot(base$price, xlab = "Observation number", ylab = "Price [in $]")#create a plot of the "price" column

base$price <- ifelse(base$price == 0, NA, base$price)#replace all the values of the "price" column that are equal to 0 with NA (missing value)
base$price <- ifelse(base$price > 1000000, NA, base$price)#replace all the values of the "price" column that are greater than 1000000 with NA (missing value).
base <- base[complete.cases(base), ]#remove all the rows that contain missing values (NA) in any of the columns
 
plot(base$price, xlab = "Observation number", ylab = "Price [in $]")#create a plot of the "price" column
count(base)#no. of data after rows have been removed

base$price2 <- ifelse(base$price > mean(base$price), 1, 0)#create a new column called "price2" and populate it with binary values (1 or 0) based on whether the "price" column is greater than the mean value of the "price" column
base$renovated <- ifelse(base$yr_renovated > 0, 1, 0)#create a new column called "renovated" and populate it with binary values (1 or 0) based on whether the "yr_renovated" column is greater than 0.

#Confirm the mean of the year
mean(base$yr_built)

base$build <- ifelse(base$yr_built> 1970, 1, 0)#create a new column called "build" and populate it with binary values (1 or 0) based on whether the "yr_built" column is greater than 1970.
base$basement <- ifelse(base$sqft_basement > 0, 1, 0)#create a new column called "basement" and populate it with binary values (1 or 0) based on whether the "sqft_basement" column is greater than 0.

#adjusting margins
par(mfrow=c(1,1), mar=c(2,2,1,1), cex.main=1.5)

#Selecting numeric columns
base_num <- base[, sapply(base, is.numeric)]

# Correlation analysis
cor_matrix <- cor(base_num)
corrplot(cor_matrix, method = "color")

# Creating factor for selected columns
base$waterfront <- as.factor(base$waterfront)
base$view <- as.factor(base$view)
base$condition <- as.factor(base$condition)
base$yr_built <- as.factor(base$yr_built)
base$yr_renovated <- as.factor(base$yr_renovated)
base$city <- as.factor(base$city)

#base$waterfront <- ifelse(nlevels(base$waterfront) < 2, as.factor(base$waterfront), base$waterfront)
#base$view <- ifelse(nlevels(base$view) < 2, as.factor(base$view), base$view)
#base$condition <- ifelse(nlevels(base$condition) < 2, as.factor(base$condition), base$condition)
#base$yr_built <- ifelse(nlevels(base$yr_built) < 2, as.factor(base$yr_built), base$yr_built)
#base$yr_renovated <- ifelse(nlevels(base$yr_renovated) < 2, as.factor(base$yr_renovated), base$yr_renovated)

#Creating levels for new variables created
base$price2 <- as.factor(base$price2)                                
base$renovated <- as.factor(base$renovated)                               
base$build <- as.factor(base$build)
base$basement <- as.factor(base$basement)

#view structure of dataset
View(base)

#calculates the mean of the 'price' column in the 'base' data frame. 
#then creates a histogram of the 'price' column in the 'base' data frame
mean(base$price)
base_pred <- base[,c(2:12,18:22)]
#base_pred <- base[,c(2:14,16,19:22)]

#then create a base theme and a histogram of the 'price' column in the 'base' data frame
base_theme <- theme_fivethirtyeight() +
  theme(axis.title = element_text(size = 16), 
        axis.text = element_text(size = 16), 
        axis.line = element_line(size = 0.4, colour = "grey10"))
ggplot(base_pred, aes(price)) + 
  geom_histogram(binwidth = 80000, fill = "darkslategray1", col = "black", alpha = 0.95) +
  geom_vline(xintercept = mean(base_pred$price), linetype = "longdash", size = 0.6) +
  annotate("text", x = 800000, y = 550, label = paste("Mean =", round(mean(base_pred$price)/1000,1),"k $"), size = 6.5) +
  base_theme + 
  labs(x = 'Price in $', y = "Frequency", caption = "© created by Shuaib Suleman")


#Create a new data frame wykres2 by grouping the data in base_pred by the variable price2 and counting the number of 
#observations in each group
wykres2 <- base_pred %>%
  group_by(price2) %>%
  summarize(x=n()) %>%
  as.data.frame() 

#Replace the numeric values of price2 in wykres2 with "Above average price" and "Below average price"
wykres2$price2 <- ifelse(wykres2$price2==0, "Below average price", "Above average price")

#Create a bar chart using ggplot2 package with the x-axis representing the price2 variable, y-axis representing the count and 
#fill color representing the price2 variable.
plot_theme <- theme_fivethirtyeight() +
  theme(legend.position = "none", 
        axis.title = element_text(size = 16), 
        axis.text = element_text(size = 16), 
        axis.line = element_line(size = 0.4, colour = "grey10"))
ggplot(wykres2, aes(reorder(as.factor(price2), +x), x, fill = as.factor(price2))) +
  geom_bar(stat = "identity", col = "black") +
  coord_flip() +
  scale_fill_brewer(palette = "Paired") +
  geom_text(aes(y = x/2, label = x), size = 7.5) +
  plot_theme +
  labs(x = "", y = "Frequency", caption = "© created by Shuaib Suleman")

#creating a bar chart that shows the frequency of the different number of bedrooms in the data set. It starts by grouping the data by the number of bedrooms, and then it summarizes the data to get the 
#count of occurrences for each number of bedrooms. 
mean_bedrooms <- round(mean(base$bedrooms), 2)
plot_theme <- theme_fivethirtyeight() +
  theme(legend.position = "none", 
        axis.title = element_text(size = 16), 
        axis.text = element_text(size = 16), 
        axis.line = element_line(size = 0.4, colour = "grey10"))
bedrooms_df <- base_pred %>%
  group_by(bedrooms) %>%
  summarize(x=n()) %>%
  as.data.frame()
ggplot(bedrooms_df, aes(as.factor(bedrooms), x)) +
  geom_bar(stat = "identity", col = "black", fill = "green2") +
  geom_text(aes(y = x+50, label = x), size = 5) +
  annotate("text", x = 5.8, y = 1600, label = paste("Mean =", mean_bedrooms), size = 7) +
  plot_theme +
  labs(x = "Number of bedrooms", y = "Frequency", caption = "© created by Shuaib Suleman")


#creates a histogram of the sqft_living variable in the base_pred data set
ggplot(base_pred, aes(sqft_living))+
  geom_histogram(binwidth = 500, fill = "lightblue", col = "black", alpha = 0.95)+
  geom_vline(xintercept = mean(base_pred$sqft_living), linetype = "longdash", size = 0.6)+
  annotate("text", x = 3800, y = 800, label = "Mean = 1998 sqft", size = 6.8)+
  theme_fivethirtyeight()+
  theme(axis.title = element_text(size = 16), axis.text = element_text(size = 16), axis.line = element_line(size = 0.4, colour = "grey10"))+ 
  labs(x = "House area in square feet", y = "Frequency", caption = "© created by Shuaib Suleman")


#calculates the average value of the "sqft_lot" variable in the "base_pred" data set, then it creates a histogram of the "sqft_lot" variable
mean(base$sqft_lot)
ggplot(base, aes(sqft_lot))+
  geom_histogram(binwidth = 5000, fill = "green", col = "black", alpha = 0.95)+
  geom_vline(xintercept = mean(base$sqft_lot), linetype = "longdash", size = 0.6)+
  scale_x_continuous(limits =c(0,50000))+
  annotate("text", x = 26000, y = 1200, label = "Mean = 14282.56 sqft", size = 6.8)+
  theme_fivethirtyeight()+
  theme(axis.title = element_text(size = 16), axis.text = element_text(size = 16), axis.line = element_line(size = 0.4, colour = "grey10"))+ 
  labs(x = 'Plot area in square feet', y = "Frequency", caption = "© created by Shuaib Suleman")


#creates a scatterplot to visualize the relationship between two variables, 'sqft_living' and 'price', in a data frame named 'base'. 
#It uses the ggplot library and specifies 'sqft_living' as the x-axis and 'price' as the y-axis. The plot is annotated with labels for the x and 
#y axis, as well as a title. The alpha argument of the geom_point function controls the transparency of the points in the plot.
ggplot(base, aes(sqft_living, price)) +
  geom_point(alpha = 0.5) +
  ggtitle("Relationship between Price and Living Area (sqft)") +
  xlab("Living Area (sqft)") +
  ylab("Price")

#produces a bar chart that shows the frequency of houses in the data set based on whether they have a waterfront location or not. 
base_pred %>%
  group_by(waterfront) %>%
  summarize(x=n()) %>%
  as.data.frame() %>%
  ggplot(., aes(reorder(as.factor(waterfront), +x), x, fill = as.factor(waterfront)))+
  geom_bar(stat = "identity", col = "black")+
  scale_fill_brewer(palette = "Paired")+
  geom_text(aes(y = x+150, label = x), size = 7.5)+
  theme_fivethirtyeight()+
  theme(legend.position = "none", axis.title = element_text(size = 16), axis.text = element_text(size = 16), axis.line = element_line(size = 0.4, colour = "grey10"))+
  labs(x = "Location by the sea : Yes = 1", y = "Frequency", caption = "© created by Shuaib Suleman")


#creating a bar chart that shows the frequency of different condition ratings of houses in the dataset base_pred.
base_pred %>%
  group_by(condition) %>%
  summarize(x=n()) %>%
  as.data.frame() %>%
  ggplot(., aes(condition, x, fill = as.factor(condition)))+
  geom_bar(stat = "identity", col = "black", alpha = .85)+
  scale_fill_brewer(palette = "Pastel2")+
  geom_text(aes(y = x+120, label = x), size = 7.5)+
  theme_fivethirtyeight()+
  theme(legend.position = "none", axis.title = element_text(size = 16), axis.text = element_text(size = 16), axis.line = element_line(size = 0.4, colour = "grey10"))+
  labs(x = "House condition [from 1 to 5]", y = "Frequency", caption = "© created by Shuaib Suleman")

# creating a histogram to visualize the distribution of the "sqft_above" variable in the "base_pred" dataframe
ggplot(base_pred, aes(sqft_above))+
  geom_histogram(binwidth = 400, fill = "lightgreen", col = "black", alpha = 0.95)+
  geom_vline(xintercept = mean(base_pred$sqft_above), linetype = "longdash", size = 0.6)+
  annotate("text", x = 3080, y = 1000, label = "Mean = 1719.98 sqft", size = 7.5)+
  theme_fivethirtyeight()+
  theme(axis.title = element_text(size = 16), axis.text = element_text(size = 16), axis.line = element_line(size = 0.4, colour = "grey10"))+ 
  labs(x = 'Above ground area in square feet', y = "Frequency", caption = "© created by Shuaib Suleman")

#grouping the dataframe base_pred by the variable renovated, and then summarize the data by counting the number of rows for each group.
#converts the resulting summary data into a dataframe, create a bar chart using ggplot
base_pred %>%
  group_by(renovated) %>%
  summarize(x=n()) %>%
  as.data.frame() %>%
  ggplot(., aes(as.factor(renovated), x, fill = as.factor(renovated)))+
  geom_bar(stat = "identity", col = "black", alpha = 0.95)+
  scale_fill_brewer(palette = "Set1")+
  geom_text(aes(y = x-180, label = x), size = 7.5)+
  theme_fivethirtyeight()+
  theme(legend.position = "none", axis.title = element_text(size = 16), axis.text = element_text(size = 16), axis.line = element_line(size = 0.4, colour = "grey10"))+
  labs(x = "No. of Homes Renovated: Yes = 1", y = "Frequency", caption = "© created by Shuaib Suleman")


#creating a bar chart that groups the data in the "base_pred" dataframe by the column "build" and then counts the number of observations in 
#each group. It then creates a dataframe with the count of observations and the group name. This dataframe is then used to create a bar 
#chart 
base_pred %>%
  group_by(build) %>%
  summarize(x=n()) %>%
  as.data.frame() %>%
  ggplot(., aes(as.factor(build), x, fill = as.factor(build)))+
  geom_bar(stat = "identity", col = "black", alpha = 0.95)+
  scale_fill_brewer(palette = "Set2")+
  geom_text(aes(y = x-150, label = x), size = 7.5)+
  theme_fivethirtyeight()+
  theme(legend.position = "none", axis.title = element_text(size = 16), axis.text = element_text(size = 16), axis.line = element_line(size = 0.4, colour = "grey10"))+
  labs(x = "Built after 1970 : Yes = 1", y = "Frequency", caption = "© created by Shuaib Suleman")


# creating a bar chart to show the frequency of houses with a basement versus those without a basement. The code first groups the data by 
#the 'basement' variable, which likely indicates whether a house has a basement or not. Then it summarizes the number of houses in each 
#group and converts the resulting data to a data frame. The resulting data frame is then used to create a bar chart
base_pred %>%
  group_by(basement) %>%
  summarize(x=n()) %>%
  as.data.frame() %>%
  ggplot(., aes(as.factor(basement), x, fill = as.factor(basement)))+
  geom_bar(stat = "identity", col = "black", alpha = 0.95)+
  scale_fill_brewer(palette = "Pastel1")+
  geom_text(aes(y = x-180, label = x), size = 7.5)+
  theme_fivethirtyeight()+
  theme(legend.position = "none", axis.title = element_text(size = 16), axis.text = element_text(size = 16), axis.line = element_line(size = 0.4, colour = "grey10"))+
  labs(x = "Basement: Yes = 1", y = "Frequency", caption = "© created by Shuaib Suleman")

View(base_pred)

base_pred[,c(1:16)] <- lapply(base_pred[,c(1:16)], as.numeric)

#create a correlation plot of the data in the base_pred dataframe. The data used for the correlation plot are the columns 2, 3, 6, and 11 
#of the dataframe. The plot shows the correlation coefficients between the different variables represented by color.
corrplot(cor(base_pred[,c(1,2,3,4,5,6,7,10)]), method = "color", type = "upper", tl.col = "black",tl.srt = 90, 
         addCoef.col = "black", diag = T, number.cex = 1.5)


#creates a scatter plot of the relationship between two variables: sqft_living and sqft_above. It plots the data points as blue circles
ggplot(base_pred, aes(sqft_living, sqft_above))+
  geom_point(colour = "blue", shape = 20, size = 4.5, alpha = 0.09)+ 
  geom_smooth(method = lm, col = "dodgerblue4", fill = "lightsteelblue3", size = 1.2, formula = y ~ x)+
  annotate("text", x = 5050, y = 4500, label = "italic(r) == 0.85", parse = T, size = 8.5, col = "gray20")+
  labs(x = "House area", y = "Aboveground areas", caption = "© created by Shuaib Suleman")+
  theme_fivethirtyeight()+
  theme(axis.text.x = element_text(size = 16), axis.text.y = element_text(size = 16), axis.title = element_text(size = 16),
        axis.line = element_line(size = 0.4, colour = "grey10"))

#creates a scatterplot in R using the ggplot library to visualize the relationship between the price of a property and the number of bathrooms it has.
#The plot uses the base data frame and maps the number of bathrooms to the x-axis and the price to the y-axis. The plot includes a title, x-axis label,
#and y-axis label to describe the data being plotted.
ggplot(base, aes(bathrooms, price)) +
  geom_point(alpha = 0.5) +
  ggtitle("Relationship between Price and Bathrooms") +
  xlab("Bathrooms") +
  ylab("Price")

##########################################

# Feature importance analysis (using random forest)
set.seed(150)
control <- trainControl(method = "repeatedcv", number = 10, repeats = 3)
model2 <- train(price ~ bedrooms + bathrooms + sqft_living + waterfront + view + condition + sqft_above + renovated + build + basement, data = base, method = "rf", trControl = control)
varImp(model2)


####Model Development #########################################

# Linear regression to understand importance of variables on target 
modelX1 <- glm(price ~ bedrooms + bathrooms + sqft_living + build, data = base)
summary(modelX1)

# Linear regression to understand importance of variables on target 
modelX2 <- glm(price ~ bedrooms + bathrooms + sqft_living + sqft_above + floors + build + basement, data = base)
summary(modelX2)

# Linear regression to understand importance of variables on target 
modelx3 <- glm(price ~ bedrooms + bathrooms + sqft_living + waterfront + sqft_above  + floors + build + basement, data = base)
summary(modelx3)

# Check for normality of residuals using a histogram and Q-Q plot
resid <- residuals(modelx3)
ggplot() +
  geom_histogram(aes(x = resid), binwidth = 2, fill = "lightblue") +
  ggtitle("Histogram of Residuals")

#Q-Q plot
ggplot() +
  stat_qq(aes(sample = resid)) +
  stat_qq_line() +
  ggtitle("Q-Q Plot of Residuals")

# Check for linearity using a scatter plot
ggplot() +
  geom_point(aes(x = modelx3$fitted.values, y = resid)) +
  geom_smooth(aes(x = modelx3$fitted.values, y = resid), method = "loess") +
  ggtitle("Residuals vs. Fitted Values")

# Check for homoscedasticity using a plot of residuals vs. fitted values
crPlots(modelx3)


#residual deviance reduces with the addition of coefficient
anova(modelX1, "PChiSq")
anova(modelX2, "PChiSq")
anova(modelx3,"PChiSq")

#comparison of the models
anova(modelX1, modelX2, modelx3, test="Chisq")

#Model Fit verification
(pseudo_R_sq=1-(modelX1$deviance/modelX1$null.deviance))
(pseudo_R_sq=1-(modelX2$deviance/modelX2$null.deviance))
(pseudo_R_sq=1-(modelx3$deviance/modelx3$null.deviance))

###############################################################################################
#model validation - DATA PARTITION 
set.seed(1234)
ind <- sample(2, nrow(base_pred), replace = TRUE, prob = c(0.8, 0.2))
Training_Data=base[ind==1,] 
Testing_Data=base[ind==2,]
summary(Training_Data)
summary(Testing_Data)

#New data
new_data=data.frame(bedroom = 3, Bathrooms = 3, sqft_living = 14000)
new_data

#predict
pl=predict(modelx3, Testing_Data, type="response")
pl
attributes(pl) 
pl=ifelse(pl>.5,1,0)

#Miscalssification error -test data
p2=predict(modelx3, Testing_Data, type="response")
p2
p2=ifelse(p2>.5,1,0) 
p2

length(Testing_Data)
length(p2)
length(Training_Data)
(t2=table(predicted = p2, Actual = Testing_Data$Attrition))
(t2=table(predicted = p2, Actual = Testing_Data$Attrition)) 
1-sum(diag(t2))/sum(t2)

(tl=table(Predicted = pl, Actual=Training_Data$Attrition))

#Goodness of fit
with(modelx3,pchisq(modelx3$null.deviance-modelx3$deviance, modelx3$df.null-modelx3$df.residual, lower.tail =))


#performing chi-squared independence tests on several pairs of categorical variables in the base_pred dataframe. The chi_kwadrat function 
#calculates the chi-squared test statistic for a given 2-dimensional table of counts. The script then calculates the square root of the 
#test statistic divided by the total number of observations for the table for each pair of variables. The results of these calculations are 
#stored in the wektor vector.
View(base_pred)

base_pred <- base_pred[,-8:-12]# we remove the waterfront variable

chi_kwadrat <- function(x){
  as.numeric(chisq.test(x)[1])
}

wektor <- c(round(sqrt(chi_kwadrat(table(base_pred[,c(2,5)]))/4211),3),
            round(sqrt(chi_kwadrat(table(base_pred[,c(3,5)]))/4211),3),
            round(sqrt(chi_kwadrat(table(base_pred[,c(4,5)]))/4211),3),
            round(sqrt(chi_kwadrat(table(base_pred[,c(5,10)]))/4211),3),
            round(sqrt(chi_kwadrat(table(base_pred[,c(5,11)]))/4211),3),
            round(sqrt(chi_kwadrat(table(base_pred[,c(2,3)]))/4211),3))
wektor

#N.B: Each element of the wektor vector reflects the square root of the test statistic divided by the total number of observations for a certain pair 
#of independent variables. The bigger the value of the standardized test statistic, the stronger the evidence against the assumption of independence 
#between the two variables, indicating a substantial relationship.The lower values of the standard test statistic in the wektor 
#vector (e.g., 0.641, 0.911) suggest less evidence of connection between the respective pairs of variables.



#selects a random subset of the rows in the base_pred data frame by using the sample() function.selected rows are assigned to the test data 
#frame, and the remaining rows are assigned to the train data frame.
set.seed(100)
losowe <- sample(nrow(base_pred), nrow(base_pred)/4, replace = F)
test <- base_pred[losowe,]
train <- base_pred[-losowe,]

cat("Number of rows in the training set: ", nrow(train), "    ")
cat("Number of rows in the test set: ", nrow(test))

#performs a decision tree analysis using the rpart function in R. It uses the price2 variable as the target variable, and all other 
#variables in the train data as the predictors. The control argument specifies the complexity parameter (cp) to be 0, which means that 
#the tree will be grown until it reaches the maximum size possible, and the number of cross-validations to be 10. 
drzewo <- rpart(as.character(price2) ~ ., data = train, control = rpart.control(cp = 0, xval = 10))
bledy <- printcp(drzewo)

View(base_pred)
##########################CG######### Make predictions on the test set
test_predictions <- predict(drzewo, newdata = test, type = "class")
test_df <- data.frame(actual = test$price2, predicted = test_predictions)
test_df$predicted <- factor(test_df$predicted, levels = levels(test_df$actual))

test_df <- data.frame(actual = test$price2, predicted = test_predictions)
test_df$predicted <- as.factor(test_df$predicted)
conf_matrix <- table(test_df$actual, test_df$predicted)



# Create a confusion matrix
conf_matrix <- table(test_predictions, test$price2)

# Calculate accuracy, precision, recall, and F1-score
accuracy <- sum(diag(conf_matrix))/sum(conf_matrix)
precision <- diag(conf_matrix)/colSums(conf_matrix)
recall <- diag(conf_matrix)/rowSums(conf_matrix)
f1_score <- 2*(precision*recall)/(precision+recall)

# Print the results
cat("Accuracy: ", accuracy, "\n")
cat("Precision: ", precision, "\n")
cat("Recall: ", recall, "\n")
cat("F1-score: ", f1_score, "\n")
##############################################################
#prune a decision tree built using the rpart package. It first identifies the best complexity parameter (CP) of the tree using the 
#cross-validation error and standard deviation, then prunes the tree using this identified CP and print the result
tmp1 <- which.min(bledy[, "xerror"]) 
tmp2 <- sum(bledy[tmp1, c("xerror", "xstd")])
optymalny <- which(bledy[, "xerror"] < tmp2)[1]

#drzewo2 <- prune(base_pred, cp = bledy[optymalny, "CP"])
drzewo2 <- prune(drzewo, cp = bledy[optymalny, "CP"])
printcp(drzewo2)

#pruned decision tree that is then visualized using the "rpart.plot" function, and the "rpart.rules" function is also used to display 
#the rules of the decision tree along with their coverage.
rpart.plot(drzewo2, fallen.leaves = F,under = T, type = 4, digits = 2, cex = 0.9)
print(rpart.rules(drzewo2, cover = T))


#creating a bar chart visualization that represents the relative importance of each feature in the decision tree model.
waz_zmien0 <- as.data.frame(cbind(drzewo2$variable.importance))
waz_zmien0 <- tibble::rownames_to_column(waz_zmien0, "x")
names(waz_zmien0) <- c("Zmien", "Wag")
ggplot(waz_zmien0, aes(reorder(Zmien, +Wag), Wag))+
  geom_segment(aes(xend = Zmien, yend = 0))+
  coord_flip()+
  geom_point(size=20, color="black", fill = "cornflowerblue", shape = 21)+
  geom_text(aes(label = round(Wag,1)), position = position_stack(vjust = 1.0), size = 5.5)+
  scale_y_continuous(limits = c(0,430))+
  labs(x = "", y = "Importance of the feature", caption = "© created by Shuaib Suleman")+
  theme_fivethirtyeight()+
  theme(axis.title = element_text(size = 16), axis.text = element_text(size = 16))


#using the "predict()" function to make predictions on a test dataset (provided in the "newdata" argument) using a previously 
#created model object called "drzewo2
Predction <- predict(object = drzewo2, newdata = test, type = "class")
cat("Prediction error on the test set: ", round(sum(Predction != test$price2) / nrow(test),4))

#creates a confusion matrix by comparing the "Real" values in the "price2" column of the "test" dataframe, to the "Prediction" values
table(Real = test$price2, Predction)


#converting the "price2" column in the "train" and "test" data sets to a factor variable, and then using the "bagging" function to perform 
#bagging on the "price2" column as the response variable, with all other columns as the predictor variables, using the "train" data set 
#and creating 30 final models
train$price2 <- as.factor(train$price2)
test$price2 <- as.factor(test$price2)
bagging <- bagging(price2 ~., data = train, mfinal = 30)

#selecting a random tree from the bagging model and plotting it using the "prp" function, which stands for "party package plot" and is used 
#to create plots of decision trees
bagging$trees[[sample(1:30,1)]]
prp(bagging$trees[[sample(1:30,1)]], nn = T, fallen.leaves = T, branch.lty = 5, branch = 0.1,
    faclen = 0, trace = 0, split.cex = 1.2,  split.prefix = "Is ", split.suffix = "?",
    split.box.col = "lightblue2", split.border.col = "navy", split.round = 1.2)

#creating a data frame from the cross-tabulation of the "price2" column in the "train" data set and the first column of the "votes" 
#variable in the bagging model, and then using the ggplot2 package to create a heatmap of the frequency of votes for each level of the 
#"price2" variable.
glosowania <- as.data.frame(table(train$price2, bagging$votes[, 1]))
ggplot(glosowania, aes(x = Var1, y = Var2, fill = Freq)) + 
  geom_tile()+
  scale_fill_distiller(palette="Spectral")+
  geom_text(aes(label=Freq))+
  labs(x = "Explained feature's levels", y = "Number of votes", caption = "© created by Shuaib Suleman")+
  theme_fivethirtyeight()+
  theme(axis.text.x = element_text(size=12), axis.text.y = element_text(size=12), axis.title = element_text(size=14))

#creates a dataframe from the "importance" variable in the bagging model and sorts the values in descending order using the sort function,
waz_zmien <- as.data.frame(sort(bagging$importance, decreasing = T))
waz_zmien <- tibble::rownames_to_column(waz_zmien, "x")
names(waz_zmien) <- c("Zmien", "Wag")

#creates a bar chart using the ggplot,  
ggplot(waz_zmien, aes(reorder(Zmien, +Wag), Wag))+
  geom_segment(aes(xend=Zmien, yend=0))+
  coord_flip()+
  geom_point(size=20, color="black", fill = "mediumvioletred", shape = 21)+
  geom_text(aes(label = round(Wag,1)), position = position_stack(vjust = 1.0), size = 5.5)+
  scale_y_continuous(limits = c(0,90))+
  labs(x = "", y = "Importance of the feature", caption = "© created by Shuaib Suleman")+
  theme_fivethirtyeight()+
  theme(axis.title = element_text(size = 16), axis.text = element_text(size = 16))

#creating a bagging model uses 10-fold cross-validation and 30 final models
a <- bagging.cv(price2~., data = train, v = 10, mfinal = 30)
cat("Prediction error from cross validation (bagging): ", round(a$error, 4))

#using the 'predict' function to generate predictions for the 'test' dataset using the 'bagging' model. The 'type' argument is set to "class" which means that the predictions 
#are for categorical variables. 
predykcja2 <- predict(object = bagging, newdata = test, type = "class")
cat("Prediction error on the test set (bagging): ", round(mean(predict(bagging, test)$class != test$price2),4))

#creates a contingency table that compares the "Real" values of the "price2" column in the "test" data set with the "Prediction" values from 
#the "predykcja2" object. 
table(Real = test$price2, Prediction = predykcja2$class)

#code creates a plot that shows the evolution of the error rate for the bagging model, both on the test and training sets. The errorevol() 
#function is used to calculate the error rate for each iteration of the bagging algorithm, and the plot.errorevol() function is used to create the plot. 
plot.errorevol(errorevol(bagging, test), errorevol(bagging, train))



#training a boosting model on the "train" data set, using all the columns except the "price2" column as predictors. 
#The "mfinal" parameter is set to 30, which means that the final model will be created using 30 iterations of the boosting algorithm.
boosting <- boosting(price2 ~., data = train, mfinal = 30)

#selects a random tree from the 30 trees that were created during the boosting process 
#visualizes the selected tree using the prp() function.
boosting$trees[[sample(1:30,1)]]
prp(bagging$trees[[sample(1:30,1)]], nn = T, fallen.leaves = T, branch.lty = 5, branch = 0.1,
    faclen = 0, trace = 0, split.cex = 1.2,  split.prefix = "Is ", split.suffix = "?",
    split.box.col = "lightblue2", split.border.col = "navy", split.round = 1.2)

#extracting the sum of the weights of the boosting model's trees.
#creating a variable 'tak' which is cutting the weights of the trees that correspond to "0" class in the train data into 7 equal parts.
#creating a variable 'nie' which is cutting the weights of the trees that correspond to "1" class in the train data into 7 equal parts.
#plotting a bar plot of the frequency of the "tak" and "nie" variables.
#adding a legend to the plot with the label 'Cheap' and 'Expensive' for the "0" and "1" classes respectively.
suma_wag <- sum(boosting$votes[1,])
tak <- cut(boosting$votes[train$price2 == "0",1], seq(0,suma_wag,length.out = 7))
nie <- cut(boosting$votes[train$price2 == "1",1], seq(0,suma_wag,length.out = 7))
barplot(rbind(table(tak), table(nie)), space = F)
legend(0.4,600, c("Cheap","Expensive"), lty=1, col=c("gray","black"), bty="n", seg.len = 5)




waz_zmien2 <- as.data.frame(sort(boosting$importance, decreasing = T))
waz_set_seed2 <- tibble::rownames_to_column(waz_zmien2, "x")
names(waz_set_seed2) <- c("Zmien", "Wag")

ggplot(waz_set_seed2, aes(Zmien, Wag))+
  geom_segment(aes(xend = Zmien, yend =0 ))+
  coord_flip()+
  geom_point(size = 20, color = "black", fill = "chocolate3", shape = 21)+
  geom_text(aes(label = round(Wag,1)), position = position_stack(vjust = 1.0), size = 5.5)+
  scale_y_continuous(limits = c(0,80))+
  labs(x = "", y = "Importance of the feature", caption = "© Made by Michau96/Kaggle")+
  theme_fivethirtyeight()+
  theme(axis.title = element_text(size = 16), axis.text = element_text(size = 16))



b <- boosting.cv(price2~., data = train, v = 10, mfinal=30)
cat("Prediction error from cross validation (boosting): ", round(b$error,4))

predykcja3 <- predict(object = boosting, newdata = test, type = "class")
cat("Prediction error on the test set (boosting): ", round(mean(predict(boosting, test)$class != test$price2),4))

table(Real = test$price2, Prediction = predykcja3$class)

plot.errorevol(errorevol(boosting, test), errorevol(boosting, train))

boosting2 <- boosting(price2 ~., data = train, mfinal = 10)
predykcja4 <- predict(object = boosting2, newdata = test, type = "class")
cat("Prediction error on the test set (boosting2): ", round(mean(predict(boosting2, test)$class != test$price2),4))

str(train)
# Convert the character variables to factors
base$date <- as.factor(base$date)
base$street <- as.factor(base$street)
base$city <- as.factor(base$city)
base$statezip <- as.factor(base$statezip)
base$country <- as.factor(base$country)
train$price <- as.factor(train$price)
train$bedrooms <- as.factor(train$bedrooms)
train$bathrooms <- as.factor(train$bathrooms)
train$sqft_living <- as.factor(train$sqft_living)
train$sqft_lot <- as.factor(train$sqft_lot)
train$floors <- as.factor(train$floors)


#N.B: #creating a random forest regression model, The rfsrc function builds a random forest regression model to the "train" data set to predict the response 
#variable "price2" based on the other predictor variables. The model use a block size of 1, thus each tree in the forest will see a random subset \
#of 1 block of data.The significance argument is set to T, indicating that the variable importance scores for each predictor variable will be 
#calculated and provided in the function's output. The samptype parameter is set to "swr," which stands for "stopped-and-well-rescaled" and is a 
#method for producing bootstrapped samples. The var.used option is set to "all.trees," which means that all model variables will be evaluated for 
#split selection at each node in all trees. The 1000 value for the ntree parameter defines the number of trees to include in the random forest.
#The plot function is then utilized to produce a visualization of the random forest regression model.
randomf <- rfsrc(price2~., data = train, block.size = 1, importance = T, samptype = "swr", var.used = "all.trees", ntree = 1000)
plot(randomf)


randomf2 <- rfsrc(price2~., data = train, block.size = 1, importance = T, samptype = "swr", var.used = "all.trees", ntree = 100)
plot(randomf2)

vimp(randomf)
vimp(randomf2)

#extracts the row names of the randomf2$ object, which contains the variable importance of each feature, and orders them based on the all` importance.
zmienne <- rownames(randomf2$importance[order(randomf2$importance[,"all"]),])

#creates a plot of the top 3 most important variables from the randomf2 object.
plot.variable.rfsrc(randomf, xvar.names = tail(zmienne,3))

#N.B # uses the randomf2 model to make predictions on a test dataset and outputs a summary of the model's performance. The sample size of the test 
#dataset is 1666, and the model used 100 trees to make the predictions. The average number of terminal nodes in each tree was 437.78, and the model 
#used 11 variables. The resampling method used was "swr," and the resample size used was 2545. The analysis performed was Random Forest 
#Classification (RF-C). The classification was performed with an imbalanced ratio of 1.276, and the performance of the model was evaluated using 
#several performance metrics: Brier score, normalized Brier score, Area Under the ROC Curve (AUC), precision-recall AUC, G-mean, and 
#misclassification error.
predict(randomf, newdata = test)

#base_pred2 <- base[,c(2,3,4,5)]

View(base)
base_pred2 <- base[,c(1,2,4,5,7,9,15,16,17)]
base_pred2<- base[, sapply(base, is.numeric)]
str(base_pred2)
#sets a seed for the random number generator, which will ensure that the results are reproducible
#creates two datasets, train2 and test2, by randomly splitting the base_pred2 dataset into two parts. The sample function is used to generate a 
#random sample of size nrow(base_pred)/4 without replacement from the row indices of the base_pred2 dataset. The train2 dataset consists of all 
#the rows in base_pred2 except the randomly selected ones, while the test2 dataset consists of the randomly selected rows. This is a common practice 
#in machine learning when the goal is to train a model on a portion of the data and evaluate its performance on a separate, hold-out portion of the 
#data.
set.seed(100)
losowe <- sample(nrow(base_pred2), nrow(base_pred)/4, replace = F)
test2 <- base_pred2[losowe,]
train2 <- base_pred2[-losowe,]

cat("Number of rows in the training set: ", nrow(train2), "    ")
cat("Number of rows in the test set: ", nrow(test2))


# performs KNN regression with 1 nearest neighbor (k=1,2,3,5,8,10,20,50,100) using the FNN::knn.reg function. The first argument of the function is the training data 
#with all columns except the first (train2[,-1]). The second argument is the test data with all columns except the first (test2[,-1]). The third 
#argument is the target variable in the training data, `train2$price.
reg1 <- FNN::knn.reg(train2[,-1], test2[,-1], train2$price, k=1)
knn_pred1 <- round(reg1$pred,2)
test_price <- test2$price
head(data.frame(knn_pred1, test_price), 5)
cat("RMSE Test:", round(rmse(knn_pred1, test_price),2))

reg2 <- FNN::knn.reg(train2[,-1], test2[,-1], train2$price, k=2)
knn_pred2 <- round(reg2$pred,2)

reg3 <- FNN::knn.reg(train2[,-1], test2[,-1], train2$price, k=3)
knn_pred3 <- round(reg3$pred,2)

reg4 <- FNN::knn.reg(train2[,-1], test2[,-1], train2$price, k=5)
knn_pred4 <- round(reg4$pred,2)

reg5 <- FNN::knn.reg(train2[,-1], test2[,-1], train2$price, k=8)
knn_pred5 <- round(reg5$pred,2)

reg6 <- FNN::knn.reg(train2[,-1], test2[,-1], train2$price, k=10)
knn_pred6 <- round(reg6$pred,2)

reg7 <- FNN::knn.reg(train2[,-1], test2[,-1], train2$price, k=20)
knn_pred7 <- round(reg7$pred,2)

reg8 <- FNN::knn.reg(train2[,-1], test2[,-1], train2$price, k=50)
knn_pred8 <- round(reg8$pred,2)

reg9 <- FNN::knn.reg(train2[,-1], test2[,-1], train2$price, k=100)
knn_pred9 <- round(reg9$pred,2)

# gives an insight into the performance of the k-nearest neighbors regression model for different values of k (number of nearest neighbors), 
#and the RMSE values can be used to compare the performance of the model with different values of k.
data.frame(Number_of_neighbors= c("2", "3", "5", "8", "10", "20", "50", "100"), RMSE = c(round(rmse(knn_pred2, test_price),2),
                                                                                         round(rmse(knn_pred3, test_price),2), 
                                                                                         round(rmse(knn_pred4, test_price),2),
                                                                                         round(rmse(knn_pred5, test_price),2),
                                                                                         
                                                                                                                                                                                  round(rmse(knn_pred6, test_price),2), round(rmse(knn_pred7, test_price),2), round(rmse(knn_pred8, test_price),2), round(rmse(knn_pred9, test_price),2)))
#The code is building a random forest model using the "rfsrc" function from the "rfsrc" package to predict the "price" variable based on all the other
#variables in the "train2" dataset. The model is set to grow 1000 trees with a block size of 1 and sampling type of "swr". The "importance" argument 
#is set to "T" which means that the relative importance of each predictor will be calculated. The "var.used" argument is set to "all.trees" which 
#means that all the trees will be used to estimate the importance of the predictors.

#N.B: The output shows the importance of each predictor in the model. 
#The "sqft_living" predictor is the most important with a relative importance of 1. The "sqft_above" and "sqft_lot" predictors have relative 
#importances of 0.5757 and 0.2956 respectively. The "bathrooms" and "sqft_basement" predictors have relative importances of 0.2918 and 0.2710 
#respectively. The "floors" and "bedrooms" predictors have relative importances of 0.2587 and 0.2378 respectively.
randomf3 <- rfsrc(price~., data = train2, block.size = 1, importance = T, samptype = "swr", var.used = "all.trees", ntree = 1000)
plot(randomf3)


#using the rfsrc function from the "randomForestSRC" package to fit a random forest regression model. The formula price~. specifies that the dependent
#variable is price and all other columns in the train2 data frame will be used as independent variables. The block.size argument is set to 1, which 
#means that each tree will use a single observation for each terminal node. The importance argument is set to TRUE, which means that the relative 
#importance of each predictor variable will be calculated. The samptype argument is set to "swr", which stands for "Stratified with Replacement". 
#This means that samples will be drawn from the original data with replacement and stratified so that the proportion of each class is the same as in 
#the original data. The var.used argument is set to "all.trees", which means that all trees in the forest will be used to calculate the variable 
#importance. The ntree argument is set to 1000 for the first plot and 100 for the second plot. This argument specifies the number of trees to use in 
#the forest.

#N.B:The resulting object of the rfsrc function is then passed to the plot function to create a plot of the relative importance of each predictor 
#variable. The plot shows that the sqft_living variable has the highest importance (1.0000) followed by sqft_above (0.5757 for the first plot and 
#0.6271 for the second plot) and sqft_lot (0.2956 for the first plot and 0.3233 for the second plot). The bathrooms, sqft_basement, floors, 
#and bedrooms variables also have some importance, but they are lower than the three main variables.
randomf4 <- rfsrc(price~., data = train2, block.size = 1, importance = T, samptype = "swr", var.used = "all.trees", ntree = 100)
plot(randomf4)

#using the vimp() function from the Random Forest SRC (rfsrc) library to determine the variable importance of the random forest model named randomf4.
vimp(randomf3)
vimp(randomf4)

#calculates the root mean squared error (RMSE) of the random forest regression model randomf4 on the test data test2. The predict function is used to 
#make predictions on the test data. The output shows that the model was applied to 1052 samples with 100 trees and an average of 656.37 terminal nodes.
#The R-squared value is 0.42732993, which indicates that the model explains 42.73% of the variation in the target variable. The final output shows 
#that the RMSE of the model on the test data is 198,499.
a <- predict(randomf4, newdata = test2)
a
cat("RMSE Test:", round(rmse(a$predicted, test_price),0))


#creating a Generalized Additive Model (GAM) using the gam function from the mgcv package. The model is predicting the price variable based on three 
#predictors: sqft_living, sqft_lot, and bedrooms. The summary function is used to generate a summary of the model, 
gam1 <- gam(price ~ s(sqft_living)+s(sqft_lot)+bedrooms, data = train2)
summary(gam1)

#######
gam.check(gam1)
plot(gam1, residuals = T, pages = 1, scheme = 1, all.terms = T)
#######

#building a Generalized Additive Model (GAM) for the housing price prediction problem using the gam function from the R library.
gam2 <- gam(price ~ s(sqft_living)+s(sqft_lot), data = train2)
summary(gam2)


#N.b:The gam.check function is used to check the validity of the Generalized Additive Model (GAM) model fit. The output provides information about 
#the optimization method used (GCV), the number of iterations needed for convergence, and the RMS GCV score gradient.
#The Model rank is 19 out of 19, which indicates that all basis functions were used in the model fit. The basis dimension (k) is checked with a 
#low p-value (k-index < 1) as an indicator of whether the value of k is too low, particularly if the effective degrees of freedom (edf) are close 
#to k'.For the two smooth terms, "s(sqft_living)" and "s(sqft_lot)", the p-value is shown to be 0.475 and 0.025 respectively. This suggests that 
#the "s(sqft_living)" term does not indicate a low value of k, but the "s(sqft_lot)" term indicates a possible low value of k with a p-value of 0.025.
gam.check(gam2)
gam.check(gam1)
#After creating the plot, the code uses the "predict" function to make predictions on the "test2" dataset and store the result in the object "b". 
#Finally, the code calculates the root mean squared error (RMSE) between the predicted values "b" and the actual values in the "test_price" vector 
#and reports it, rounded to 0 decimal places. In this case, the RMSE is 194162, which means that the average difference between the predicted and 
#actual values is about 194162.
plot(gam2, residuals = T, pages = 1, scheme = 1, all.terms = T)

#uses the predict() function to make predictions for the price variable using the gam2 model and the test2 dataset. The output of the predict() 
#function is stored in the variable b.Then, the code calculates the Root Mean Squared Error (RMSE) between the predicted values stored in b and 
#the actual values stored in the test_price variable. The rmse() function calculates this error metric, and the result is rounded to the nearest 
#whole number using the round() function. The final line of code outputs the calculated RMSE value, which is "194162".This RMSE value represents the 
#average difference between the predicted and actual values, with a lower RMSE indicating a better fit between the model and the data. The RMSE value 
#of 194162 suggests that on average, the model's predictions are off by around $194,162.
b <- predict(gam2, test2)
cat("RMSE Test:", round(rmse(b, test_price),0))

#fitting a local regression model using the loess function in R. The model has the target variable "price" as a function of the predictors 
#"sqft_living", "sqft_lot", and "bedrooms". The loess function uses a span of 2 as the smoothing parameter to determine the amount of smoothing to 
#be applied to the data.
lr <- loess(price ~sqft_living+sqft_lot+bedrooms, data = train2, span = 2)
summary(lr)

#N.B: The output shows the summary of the fitted loess model. It shows the number of observations in the training data (3159), equivalent number of 
#parameters (10.03), the residual standard error (156000), and the trace of the smoother matrix (10.4). The control settings for the loess model 
#include the span, degree, family, surface, normalize, and drop.square parameters.The summary output also shows the values for the fitted parameters 
#of the loess model. However, since the model is a non-parametric model, the values of the parameters are not shown explicitly.


#building a loess regression model to predict the 'price' based on the predictor variables 'sqft_living', 'sqft_lot', and 'bedrooms'. The 'loess' 
#function fits a non-parametric regression model to the data with a smoothing span of 2.
#calculates the predictions for the test data and binds the predicted values and actual values of the target variable in a new data frame 'loes'
#calculates the Root Mean Squared Error (RMSE) of the predictions on the test data and outputs the result, which is 193339.
lr_pred <- predict(lr, test2)
loes <- cbind(lr_pred, test_price)
loes <- loes[complete.cases(loes),]
lr_pred <- loes[,1]
test_price <- loes[,2]
cat("RMSE Test:", round(rmse(lr_pred, test_price),0))

